import json,subprocess,sys,time
from pathlib import Path
label=sys.argv[1];argv=sys.argv[2:];start=time.monotonic()
r=subprocess.run(argv,text=True,capture_output=True,timeout=120)
record={'label':label,'argv':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr}
p=Path('/tmp/soodles-29-landing')
(p/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
with (p/'commands.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
sys.exit(r.returncode)
