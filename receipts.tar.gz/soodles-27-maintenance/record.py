import json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).parent
kind,expected,*argv=sys.argv[1:]
event={"argv":argv,"cwd":os.getcwd(),"kind":kind,"expected_exit":int(expected),"exit":None,"stdout":"","stderr":""}
t=time.monotonic()
try:
 r=subprocess.run(argv,stdin=subprocess.DEVNULL,text=True,capture_output=True,timeout=120)
 event.update(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
finally:
 event["seconds"]=time.monotonic()-t
 with (root/"commands.jsonl").open("a") as f:f.write(json.dumps(event)+"\n")
print(event["stdout"],end="")
print(event["stderr"],end="",file=sys.stderr)
if event["exit"] != int(expected): raise SystemExit(event["exit"] or 1)
