import copy,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/workspace/scratch/8d9f1ebaaa91/soodles/.worktrees/issue-27-verify-comparison')
out=pathlib.Path(__file__).parent;fixture=out/'compare-fixture';fixture.mkdir()
sys.path[:0]=[str(root),str(root/'tests')]
from test_landing import LandingTests
f=LandingTests();f.setUp()
try:
 claim=copy.deepcopy(f.claim);snapshot=copy.deepcopy(f.snapshot)
finally:f.doCleanups()
claim['base_head']='bcab7a8642b94c9f947b64d2fcb2762d80615cdd';claim['control_root']=str(fixture)
snapshot['branch']['commit']['sha']=snapshot['pr']['base']['sha']=claim['base_head']
cf=fixture/'claim.json';sf=fixture/'readback.json';cp=fixture/'checkpoint.json'
cf.write_text(json.dumps(claim));sf.write_text(json.dumps(snapshot))
record=[sys.executable,'-B',str(out/'record.py'),'verification']
cli=['/tmp/soodles-27-authority/publisher/soodles','landing']
def call(args,expected=0):
 r=subprocess.run([*record,str(expected),*cli,*map(str,args)],cwd=root,text=True,capture_output=True)
 assert r.returncode==0,r.stderr
 return json.loads(r.stdout)
call(['start',cf,sf,cp]);call(['advance',cp,sf]);before=cp.read_bytes()
snapshot['branch']['commit']['sha']=snapshot['pr']['base']['sha']='6673029846d228319e83ecbfe23758b023fcf487'
sf.write_text(json.dumps(snapshot))
r=call(['advance',cp,sf],1);assert cp.read_bytes()==before
(out/'comparison-refusal.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'comparison-before.sha256').write_text(hashlib.sha256(before).hexdigest())
assert r['next']['kind']=='provider_readback';print(json.dumps(r['next']['requests']['base_comparison']))
