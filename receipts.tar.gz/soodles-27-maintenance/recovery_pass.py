import json,pathlib,subprocess,sys
root=pathlib.Path('/workspace/scratch/8d9f1ebaaa91/soodles/.worktrees/issue-27-verify-comparison')
evidence=pathlib.Path(__file__).parent
binary='/tmp/soodles-runtime/noodle'
record=[sys.executable,'-B',str(evidence/'record.py')]
def drive(name,kind,argv):
 r=subprocess.run(record+[kind,'0',*argv],cwd=root,text=True,capture_output=True)
 (evidence/(name+'.stdout')).write_text(r.stdout)
 (evidence/(name+'.stderr')).write_text(r.stderr)
 if r.returncode:raise RuntimeError(name+' failed; preserve evidence, no retry')
 return r.stdout
before=drive('before','readback',['git','rev-parse','HEAD','HEAD^{tree}'])
assert not drive('before-status','readback',['git','status','--porcelain','--untracked-files=all']).strip()
doctor=json.loads(drive('doctor','verification',['./soodles','runtime','check',binary]))
listing=drive('resolution','readback',[binary,'skills','list'])
expected=root/'.agents/skills/verify-soodles'
sys.path.insert(0,str(expected/'scripts'))
from verify_runtime import resolved_skill
resolution=resolved_skill(listing,expected)
commands=[('delivery',[sys.executable,'-B','delivery_oracle.py','.']),('base',[sys.executable,'-B','base_recovery_oracle.py','.']),('lock',[sys.executable,'-B','cleanup_lock_oracle.py',binary,'.']),('cleanup',[sys.executable,'-B','-c','import json,sys; from cleanup_oracle import cleanup_recovery_probe; print(json.dumps(cleanup_recovery_probe(sys.argv[1])))',binary])]
results={}
for name,argv in commands:
 result=json.loads(drive(name,'verification',argv))
 assert result.get('cases'),name+' missing physical case evidence'
 if name=='lock':assert all(c['lock_refusal_before_deletion'] is True for c in result['cases'])
 results[name]=result
assert drive('after','readback',['git','rev-parse','HEAD','HEAD^{tree}'])==before
assert not drive('after-status','readback',['git','status','--porcelain','--untracked-files=all']).strip()
receipt={'feature':'delivery-recovery','classification':'VERIFIED','authorizes_landing':False,'candidate':dict(zip(['head','tree'],before.splitlines())),'runtime':doctor,'skill_resolution':resolution,'results':results,'counter_scope':'Top-level commands captured in commands.jsonl; delivery/base child counts are not observed. Provider fields are fixtures.'}
(evidence/'recovery.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'classification':receipt['classification'],'cases':{n:len(r['cases']) for n,r in results.items()}}))
