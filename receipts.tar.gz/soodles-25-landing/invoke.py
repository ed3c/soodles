import json,pathlib,subprocess,sys,time
out=pathlib.Path(__file__).parent
argv=['/tmp/soodles-22-authority/publisher/soodles','landing',*sys.argv[1:]]
t=time.monotonic();r=subprocess.run(argv,text=True,capture_output=True,timeout=120)
event={'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':time.monotonic()-t}
with (out/'trace.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr);raise SystemExit(r.returncode)
