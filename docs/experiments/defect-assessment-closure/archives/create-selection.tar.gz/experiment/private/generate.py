import json,sys,tempfile,hashlib,subprocess
from pathlib import Path
from unittest.mock import patch
B=Path(__file__).resolve().parents[1]
W=Path('/Users/neon/.codex/worktrees/defect-assessment-closure/soodles')
arm,case=sys.argv[1:]
source=B/'sources'/('baseline' if arm=='baseline' else 'treatment')
sys.path.insert(0,str(source));sys.path.insert(1,str(W/'tests'))
import next_issue
from test_next_issue import candidate,packet,resolved,frontier
import provider_credential
out=B/'inputs'/arm/case;out.mkdir(parents=True)
ledger=[]
c=candidate('fixture-continuation');pissue={}
def api(method,url,payload,token):
 ledger.append({'method':method,'url':url})
 if case=='unknown' and method=='POST':raise next_issue.ProviderUnknown('fixture-lost-response')
 if method=='POST':pissue.update(number=131,html_url='https://github.com/ed3c/soodles/issues/131',title=payload['title'],body=payload['body'],state='open')
 return dict(pissue)
def supplied(*args,**kwargs):
 if case=='missing':raise provider_credential.CredentialRefusal('provider_credential_profile.path','missing-or-invalid','provider_credential_profile.path')
 return 'fixture-token'
with tempfile.TemporaryDirectory(prefix='create-case-') as d:
 folder=Path(d)/'intent'
 prepared=next_issue.prepare(resolved(),packet(c),frontier(),{'kind':'local'},folder)
 def execute(env):
  try:return next_issue.execute(folder/'intent.json',environ=env,api=api)
  except next_issue.NextIssueRefusal as e:return {'owner':'next-issue','status':'refused','invalid':e.invalid,'next':e.next,'authorizes_landing':False}
 with patch.object(provider_credential,'resolve_host_environment',return_value={}),patch.object(provider_credential,'supply_token',side_effect=supplied):
  seed=execute({'GH_TOKEN':'fixture-token'}) if case=='unknown' else None
  ledger_before=list(ledger)
  result=execute({})
  state=json.loads((folder/'create-state.json').read_text()) if (folder/'create-state.json').exists() else None
  # Replace only unavailable fixture-root locators, consistently across input and receipts.
  raw=json.dumps(result).replace(str(folder),'/fixture/selected-create')
  result=json.loads(raw)
 receipt={'scope':'actual source functions with fixture provider/supplier; no network','arm':arm,'case':case,'seed':seed,'provider_before':ledger_before,'provider_after':ledger,'state':state,'result':result}
(B/'private'/f'{arm}-{case}-generation.json').write_text(json.dumps(receipt,indent=2)+'\n')
context={'repository':'ed3c/soodles','issue':131,'head':'a'*40,'carrier':'local','capture_scope':'Fixture CLI observation only; referenced production paths are unavailable in this capture. Host provider registration was available for this task.' if case!='missing' else 'Fixture CLI observation only; host provider registration was unavailable. Referenced production paths are unavailable in this capture.'}
(out/'context.json').write_text(json.dumps(context,indent=2)+'\n');(out/'owner.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'input.json').write_text(json.dumps({'owner':'owner.json','context':'context.json','instructions':['.agents/skills/next-issue/SKILL.md'],'scope':'Read current CLI observation and hand off this bounded task.'},indent=2)+'\n')
skill=out/'.agents/skills/next-issue/SKILL.md';skill.parent.mkdir(parents=True)
skill.write_bytes((W/'.agents/skills/next-issue/SKILL.md').read_bytes() if arm=='r02' else subprocess.check_output(['git','show','HEAD:.agents/skills/next-issue/SKILL.md'],cwd=W))
print(json.dumps({'arm':arm,'case':case,'result':result,'provider_calls':ledger}))
