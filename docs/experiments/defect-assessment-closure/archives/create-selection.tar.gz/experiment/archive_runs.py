"""Archive this fixed experiment's completed captures; never launch or score."""
import gzip,hashlib,io,json,tarfile,sys
from pathlib import Path

def sha(data):return hashlib.sha256(data).hexdigest()
def archive(base,destination):
 base=Path(base);destination=Path(destination);files={};runs=[]
 def add(prefix,root):
  for p in sorted(root.rglob('*')):
   if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
    files[prefix+'/'+str(p.relative_to(root))]=p.read_bytes()
 for packet in sorted((base/'host/runs').iterdir()):
  spec=json.loads((packet/'case.json').read_text());run=Path(spec['run_root'])
  cleanup=json.loads((packet/'runtime-cleanup.json').read_text())
  assert cleanup['temporary_runtime_removed'] and not cleanup['credential_bytes_archived']
  exit=json.loads((run/'raw/exit.json').read_text());assert exit['exit']==0 and exit['drained']
  observed={k:sha((run/'control'/k).read_bytes()) for k in spec['public_files']}
  assert observed==spec['public_files'],'public source changed'
  prefix='runs/'+packet.name
  add(prefix+'/packet',packet)
  for part in ['raw','output']:add(prefix+'/'+part,run/part)
  # Native session receipts, excluding logs already captured in raw.
  for p in sorted((run/'control/.noodle/sessions').glob('*/*.json')):
   files[prefix+'/sessions/'+str(p.relative_to(run/'control/.noodle/sessions'))]=p.read_bytes()
  runs.append({'run':packet.name,'original_run_root':str(run),'archive_prefix':prefix,'source_unchanged':True,'cleanup':cleanup})
 for part in ['evaluator','inputs','sources','private']:
  if (base/part).is_dir():add('experiment/'+part,base/part)
 for p in sorted(base.glob('*')):
  if p.is_file() and p.suffix in ['.json','.md','.py'] and p.name!='freeze.json':files['experiment/'+p.name]=p.read_bytes()
 for p in [base/'freeze.json',base/'host/task.md',base/'host/launch.py']:
  files['experiment/'+str(p.relative_to(base))]=p.read_bytes()
 destination.parent.mkdir(parents=True,exist_ok=True)
 with destination.open('xb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as z:
   with tarfile.open(fileobj=z,mode='w') as tar:
    for name,data in sorted(files.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
     tar.addfile(info,io.BytesIO(data))
 index={'archive':destination.name,'sha256':sha(destination.read_bytes()),'runs':runs,'members':[{'path':n,'sha256':sha(d),'bytes':len(d)} for n,d in sorted(files.items())],'credentials_archived':False}
 destination.with_suffix('.index.json').write_text(json.dumps(index,indent=2)+'\n')
 print(json.dumps({'archive':str(destination),'runs':len(runs),'members':len(files),'sha256':index['sha256']}))
if __name__=='__main__':archive(*sys.argv[1:])
