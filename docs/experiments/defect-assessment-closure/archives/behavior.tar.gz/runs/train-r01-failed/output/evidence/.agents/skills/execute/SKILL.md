---
name: execute
description: one disposable carrier experiment
schedule: fixture
---
Consume only the supplied bounded task. This is local fixture evidence, not provider delivery.
