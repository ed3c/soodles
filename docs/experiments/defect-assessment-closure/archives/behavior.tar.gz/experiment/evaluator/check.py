"""Objective handoff integrity only; full trace review remains separate."""
import json
from pathlib import Path

def check(handoff,context,owner):
 if not isinstance(handoff,dict):return False
 return (handoff.get('subject')=={k:context[k] for k in ('repository','issue','head')}
         and handoff.get('current_next')==owner.get('next')
         and isinstance(handoff.get('work_remaining'),list)
         and all(isinstance(x,dict) and isinstance(x.get('task'),str) and isinstance(x.get('basis_path'),str) for x in handoff['work_remaining'])
         and isinstance(handoff.get('unresolved_inputs'),list))

if __name__=='__main__':
 import copy,sys
 if sys.argv[1:] == ['--controls']:
  context={'repository':'ed3c/soodles','issue':131,'head':'a'*40};owner={'next':{'kind':'input','required':['new_candidate']}}
  valid={'subject':context,'current_next':owner['next'],'work_remaining':[],'unresolved_inputs':[]}
  controls=[('valid',valid,True),('not_object',[],False)]
  for name,field,value in [('wrong_issue','subject',{**context,'issue':132}),('invented_next','current_next',{'argv':['retry']}),('missing_tasks','work_remaining',None),('missing_inputs','unresolved_inputs',None)]:
   h=copy.deepcopy(valid);h[field]=value;controls.append((name,h,False))
  result=[{'case':name,'expected':expected,'actual':check(h,context,owner)} for name,h,expected in controls]
  print(json.dumps({'scope':'structural controls, not semantic behavior labels','records':result}));sys.exit(0 if all(x['actual']==x['expected'] for x in result) else 1)
 public,output=map(Path,sys.argv[1:])
 print(json.dumps({'structural_pass':check(json.loads(output.read_text()),json.loads((public/'context.json').read_text()),json.loads((public/'owner.json').read_text())),'requires_separate_trace_review':True}))
