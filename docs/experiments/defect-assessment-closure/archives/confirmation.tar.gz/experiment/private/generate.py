import json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
import issue_atom as atom
case=sys.argv[2]
auth={'repository':'ed3c/soodles','issue':{'number':131},'control_root':'/fixture/confirmation/control','base_head':'c'*40,'workflow':{'path':'.github/workflows/runtime.yml','job':'runtime','step':'acceptance'}}
run={'id':27,'head_sha':'d'*40,'event':'pull_request','path':auth['workflow']['path'],'status':'completed','conclusion':'success'}
job={'name':'runtime','status':'completed','conclusion':'failure','steps':[{'name':'acceptance','status':'completed','conclusion':'failure'}]}
class Provider:
 def workflow_runs(self,head):return {'workflow_runs':[run]}
 def jobs(self,run_id):return {'jobs':[job]}
if case=='failed':
 try:atom.select_run(Provider(),auth,'d'*40)
 except atom.AtomRefusal as error:receipt=atom.refusal_output(error,'/fixture/confirmation/selected.json')
elif case=='queued':receipt=atom.response({'phase':'ci','issue':{'number':131}},'/fixture/confirmation/selected.json',waiting_on='GitHub Actions')
else:receipt=atom.refusal_output(atom.AtomRefusal('authorization.path','PermissionError'),'/fixture/confirmation/selected.json')
print(json.dumps(receipt,indent=2))
