# Scoped eval-audit

Error analysis — Problem exists: the actual source resolver loads full committed file bytes. The selected-activation boundary shares a 45 KB file with unrelated transitions. This reproduces supply granularity; no historical Agent failure rate is inferred.
Evaluator design — Prior design checks validate JSON and SHA only, so they cannot establish context reduction or Agent correctness. Fix: independent lossless section/closure checks, actual subprocess output and fresh matched consumers answering concrete admission questions.
Judge validation — No semantic judge is used; discrete decisions are checked against fixed source clauses. No broad claim of semantic equivalence beyond lossless section extraction and these cases.
Human review — Supervisor reviews source mapping and raw responses, not PASS summaries. Not a blinded human study.
Labeled data — Four bounded consumers are a smoke comparison plus confirmation, not a population estimate.
Pipeline hygiene — Fixed protocol, immutable source and treatment, all failures retained; candidate must not alter the external judge. No global eval infrastructure is introduced.
