import copy,hashlib,json
from pathlib import Path
ROOT=Path(__file__).parent
def exact(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
def qualify():
 expected=json.loads((ROOT/'expected-supervisor-only.json').read_text());controls=[]
 for group,target in expected.items():
  assert exact(copy.deepcopy(target),target)
  for section,fields in target.items():
   for field,value in fields.items():
    bad=copy.deepcopy(target);bad[section][field]=not value if type(value) is bool else 'candidate'
    assert not exact(bad,target);controls.append(group+'.'+section+'.'+field)
 return {'classification':'QUALIFIED','positive_groups':len(expected),'planted_negative_fields':controls,'scope':'exact objective decision fields only','authorizes_landing':False}
if __name__=='__main__':
 (ROOT/'oracle-qualification.json').write_text(json.dumps(qualify(),indent=2)+'\n')
 print((ROOT/'oracle-qualification.json').read_text())
