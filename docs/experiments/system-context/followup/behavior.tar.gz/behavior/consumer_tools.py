"""Scoped process capture for explicitly disposable consumer fixtures."""
import json,os,pathlib,subprocess,sys,time
packet_path=pathlib.Path(sys.argv[1]); packet=json.loads(packet_path.read_text())
fixture=json.loads(pathlib.Path(packet['fixture']).read_text())
name=sys.argv[2];args=sys.argv[3:]
if name not in ('entry','noodle'):
    raise SystemExit('Select only the supplied entry or measured noodle help/event interface')
argv=[packet['entry'] if name=='entry' else fixture['noodle'],*args]
directory=packet_path.parent/'operations';directory.mkdir(exist_ok=True)
label=f'{len(list(directory.glob("*.json")))+1:03d}'
started=time.time()
request={'argv':argv,'cwd':fixture['cwd'],'started':started,'fixture_kind':fixture['kind']}
target=directory/(label+'.json');target.write_text(json.dumps({'request':request,'status':'offered'},indent=2)+'\n')
try:
    result=subprocess.run(argv,cwd=fixture['cwd'],env={**os.environ,**fixture['environment']},
                          capture_output=True,text=True,timeout=30)
    observation={'request':request,'status':'returned','exit_status':result.returncode,
                 'stdout':result.stdout,'stderr':result.stderr,'elapsed_seconds':time.time()-started}
except subprocess.TimeoutExpired as error:
    observation={'request':request,'status':'timeout','stdout':str(error.stdout),'stderr':str(error.stderr)}
target.write_text(json.dumps(observation,indent=2)+'\n')
print(json.dumps(observation,indent=2))
