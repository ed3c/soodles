"""Objective external event scorer; missing trace is never zero-cost success."""
import copy,json,pathlib,sys

def valid_event(events,expected):
    typed=[e for e in events if e.get('type')=='stage_message' and e.get('payload',{}).get('outcome')]
    if len(typed)!=1: return False
    event=typed[0];payload=event['payload']
    return (event.get('session_id')==expected['session_id']
            and set(payload)=={'message','blocking','outcome','order_id','stage_index'}
            and isinstance(payload['message'],str) and bool(payload['message'].strip())
            and payload['outcome']==expected['outcome']
            and type(payload['blocking']) is bool and payload['blocking']==(expected['outcome']!='completed')
            and payload['order_id']==expected['order_id']
            and type(payload['stage_index']) is int and payload['stage_index']==expected['stage_index'])

def qualify():
    expected={'session_id':'s','order_id':'o','stage_index':0,'outcome':'completed'}
    good={'type':'stage_message','session_id':'s','payload':{'message':'done','blocking':False,'outcome':'completed','order_id':'o','stage_index':0}}
    assert valid_event([good],expected)
    bad=[[],[good,good]]
    for key,value in [('message',''),('blocking',True),('blocking',0),('outcome','resolved'),('order_id','foreign'),('stage_index',1),('stage_index',False)]:
        event=copy.deepcopy(good);event['payload'][key]=value;bad.append([event])
    event=copy.deepcopy(good);event['session_id']='foreign';bad.append([event])
    for case in bad: assert not valid_event(case,expected)
    blocked=copy.deepcopy(good);blocked['payload'].update(outcome='blocked',blocking=True)
    assert valid_event([blocked],{**expected,'outcome':'blocked'})
    return {'positive_controls':2,'planted_negative_controls':len(bad),'classification':'PASS'}

def score(directory,expected_outcome):
    directory=pathlib.Path(directory);packet=json.loads((directory/'packet.json').read_text())
    fixture=json.loads(pathlib.Path(packet['fixture']).read_text());env=fixture['environment']
    if not isinstance(packet.get('admitted'),dict) or not isinstance(packet['admitted'].get('contract'),dict):
        return {'verdict':'INCONCLUSIVE','reason':'missing complete admitted contract'}
    event_path=pathlib.Path(fixture['events']);raw=event_path.read_bytes() if event_path.exists() else b''
    (directory/'events.ndjson').write_bytes(raw)
    events=[json.loads(l) for l in raw.splitlines() if l.strip()]
    capture=directory/'capture/initial/result.json'
    if not capture.is_file() or not (directory/'answer.json').is_file():
        return {'verdict':'INCONCLUSIVE','reason':'missing initial capture or final consumer report'}
    read=json.loads(capture.read_text())
    if read['exit_code']!=0 or read['timed_out']: return {'verdict':'INCONCLUSIVE','reason':'initial read failed'}
    operations=[json.loads(p.read_text()) for p in sorted((directory/'operations').glob('*.json'))]
    if any(p['status']!='returned' for p in operations): return {'verdict':'INCONCLUSIVE','reason':'incomplete process capture'}
    expected={'session_id':env['NOODLE_SESSION_ID'],'order_id':env['NOODLE_ORDER_ID'],
              'stage_index':int(env['NOODLE_STAGE_INDEX']),'outcome':expected_outcome}
    answer=json.loads((directory/'answer.json').read_text())
    return {'verdict':'PASS' if valid_event(events,expected) else 'FAIL','typed_event_correct':valid_event(events,expected),
            'recorded_operations':len(operations),'answer':answer,'scope':'initial read and declared scoped process interface; not a full platform transcript',
            'authorizes_landing':False}

if __name__=='__main__':
    if sys.argv[1:]==['qualify']: print(json.dumps(qualify(),indent=2))
    else: print(json.dumps(score(sys.argv[1],sys.argv[2]),indent=2))
