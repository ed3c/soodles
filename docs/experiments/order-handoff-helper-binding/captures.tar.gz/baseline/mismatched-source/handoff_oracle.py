import os
from pathlib import Path
marker = Path(os.environ["SOODLES_PLANTED_HELPER_MARKER"])
marker.write_text("candidate helper executed\n")
raise RuntimeError("candidate helper executed")
