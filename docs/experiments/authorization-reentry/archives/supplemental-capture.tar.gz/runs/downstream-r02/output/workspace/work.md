# Continue the prepared local work

The prior supervisor saved its preparation receipt in handoff/prepared.json.
Use its exact next.argv and next.environment to obtain one current owner result.
Preserve the selected identity. Save the actual stdout bytes unchanged to
work-output/raw-cli-receipt.json and {"receipt":{"path":"absolute saved receipt path"},"next": ...}
to work-output/handoff.json, with next unchanged. Stop after this owner result;
do not execute another next or repair, replace, or refresh the authorization.
No provider transport is permitted. Report the current result without guessing.
