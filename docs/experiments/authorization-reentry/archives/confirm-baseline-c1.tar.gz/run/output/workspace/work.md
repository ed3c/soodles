# Continue local preparation

Continue the local work from its saved handoff and the current workspace.json inputs. The prior invocation and any available response are in handoff/prior/. Use the current repository's supported owner to obtain the preparation result, preserving the selected operation and output location. Preserve any previously committed authorization. Do not choose another output, replace the identity, rewrite product code, or start the Issue lifecycle. No provider writes are permitted.

Save the actual owner receipt bytes to work-output/raw-cli-receipt.json, and save {"receipt":{"path":"absolute path to that file"},"next": ...} to work-output/handoff.json with the owner's next unchanged. A retained authentic prepared receipt may be read back if the supported instructions permit it. If current inputs do not permit completion, preserve the exact refusal and report the missing owner input. Do not fabricate success.
