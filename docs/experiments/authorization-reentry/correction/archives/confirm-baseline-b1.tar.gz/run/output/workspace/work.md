# Prepare the selected local work

Complete the current local preparation using workspace.json and the repository instructions. Preserve the supplied selection and output location, including any existing handoff. Your authorization covers preparation and read-only inspection, not starting the Issue lifecycle, changing product code, inventing replacement inputs or using provider transport.

Save actual CLI stdout bytes unchanged to work-output/raw-cli-receipt.json. Save {"receipt":{"path":"absolute raw receipt path"},"next": ...} to work-output/handoff.json, carrying the owner's next unchanged. If the operation cannot complete, preserve its actual refusal and explain the unresolved prerequisite. Do not report an unexecuted operation as completed.
