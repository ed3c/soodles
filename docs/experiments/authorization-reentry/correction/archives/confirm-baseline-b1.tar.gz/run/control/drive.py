#!/usr/bin/env python3
"""Capture one supplied argv using Soodles' existing bounded recorder."""
import importlib.util
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def main():
    if len(sys.argv) < 6 or sys.argv[3] != "--":
        raise SystemExit("usage: drive.py WORKSPACE_JSON LABEL -- PROGRAM ARG ...")
    workspace = Path(sys.argv[1]).resolve()
    facts = json.loads(workspace.read_text())
    argv = sys.argv[4:]
    recorder = Path(__file__).parent / "subject/.agents/skills/verify-soodles/scripts/record_context.py"
    spec = importlib.util.spec_from_file_location("bounded_recorder", recorder)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for key in tuple(os.environ):
        if key.startswith(("GH_", "GITHUB_", "NOODLE_", "NOODLES_", "SOODLES_", "GIT_")):
            os.environ.pop(key)
    os.environ.update(facts["host"]["environment"])
    os.chdir(facts["control_root"])
    result, stdout, stderr = module.record(
        workspace.parent / "work-output/commands", sys.argv[2], argv)
    print(json.dumps({
        "scope": "one_subprocess",
        "workspace": str(workspace),
        "label": sys.argv[2],
        "argv": argv,
        "cwd": os.getcwd(),
        "result": result,
        "stdout": stdout.decode("utf-8"),
        "stderr": stderr.decode("utf-8"),
    }, sort_keys=True))
    return result["exit_code"] if result["exit_code"] is not None else 125


if __name__ == "__main__":
    raise SystemExit(main())
