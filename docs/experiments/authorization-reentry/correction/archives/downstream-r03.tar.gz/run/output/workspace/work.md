# Continue the saved local work

A previous Session saved the actual preparation receipt in handoff/prepared.json. Use its exact next.argv and environment to obtain one current owner result. Save actual stdout unchanged to work-output/raw-cli-receipt.json and {"receipt":{"path":"absolute raw receipt path"},"next": ...} to work-output/handoff.json with next unchanged. Stop after that result. Preserve selected identity; do not repair, replace or refresh authorization or use provider transport. Report the observed result.
