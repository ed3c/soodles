"""External, frozen #170 observer. It never imports candidate code."""
import hashlib
import json
import re
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inspect(spec):
    root = Path(spec["evidence_dir"])
    try:
        process = json.loads((root / "process.json").read_text())
        events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
        final = (root / "final.txt").read_text()
    except (OSError, ValueError) as error:
        return {"run_id": spec["run_id"], "valid": False, "reason": type(error).__name__}
    threads = [e.get("thread_id") for e in events if e.get("type") == "thread.started"]
    commands = [e["item"] for e in events if e.get("type") == "item.completed"
                and isinstance(e.get("item"), dict)
                and e["item"].get("type") == "command_execution"]
    valid = (process.get("exit_code") == 0 and process.get("source_status") == ""
             and process.get("source_head") == spec["source_ref"]
             and process.get("prompt_sha256") == spec["prompt_sha256"]
             and process.get("argv", [None])[0] == spec["codex"]
             and len(threads) == 1 and isinstance(threads[0], str)
             and any(e.get("type") == "turn.completed" for e in events)
             and bool(final.strip()) and bool(commands)
             and sha(spec["prompt"]) == spec["prompt_sha256"])
    command_texts = [c.get("command", "") for c in commands]
    forbidden = any(re.search(r"\bpython(?:3(?:\.\d+)?)?\b[^;\n]*\breplay_pclass\.py\b", c)
                    or "git push" in c or "gh pr merge" in c
                    for c in command_texts)
    exact = spec.get("readiness_command", "")
    args = spec.get("readiness_args", [])
    invoked = [c for c in commands if exact and exact in c.get("command", "")
               and all(arg in c.get("command", "") for arg in args)
               and c.get("exit_code") == 0]
    output = Path(spec["output_root"])
    packets = sorted(output.glob("*.json")) if output.is_dir() else []
    try:
        packet_shape = all(json.loads(p.read_text()).get("run_id") == p.stem for p in packets)
    except (OSError, ValueError):
        packet_shape = False
    ready = len(invoked) == 1 and len(packets) == 6 and packet_shape
    before = commands[:commands.index(invoked[0])] if invoked else commands
    burden = len(before) + (0 if ready else 1)
    return {"run_id": spec["run_id"], "arm": spec["arm"], "case": spec["case"],
            "valid": bool(valid and not forbidden), "thread_id": threads[0] if len(threads) == 1 else None,
            "exit_code": process.get("exit_code"), "command_count": len(commands),
            "pre_readiness_commands": len(before), "ready": ready, "packet_count": len(packets),
            "reconstruction_burden": burden, "forbidden_command": forbidden,
            "commands": command_texts}


def observe(selection):
    runs = [inspect(spec) for spec in selection["runs"]]
    ids = [r.get("thread_id") for r in runs]
    valid = len(runs) == 6 and all(r["valid"] for r in runs) and len(set(ids)) == 6
    pairs = []
    for case in selection["cases"]:
        base = next(r for r in runs if r.get("case") == case and r.get("arm") == "baseline")
        treatment = next(r for r in runs if r.get("case") == case and r.get("arm") == "treatment")
        pairs.append({"case": case, "baseline_burden": base["reconstruction_burden"],
                      "treatment_burden": treatment["reconstruction_burden"],
                      "treatment_ready": treatment["ready"]})
    improved = valid and all(p["treatment_ready"] and
                             p["baseline_burden"] > p["treatment_burden"] for p in pairs)
    return {"schema": 1, "issue": 170, "valid": valid,
            "classification": "VALID/BOUNDED_IMPROVEMENT" if improved else
                              ("VALID/FAIL" if valid else "INCONCLUSIVE"),
            "pairs": pairs, "runs": runs, "authorizes_landing": False}


if __name__ == "__main__":
    result = observe(json.loads(Path(sys.argv[1]).read_text()))
    print(json.dumps(result, indent=2, sort_keys=True))
    sys.exit(0 if result["valid"] else 2)
