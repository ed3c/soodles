"""Run one frozen #170 fresh Codex consumer and preserve its process result."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


spec = json.loads(Path(sys.argv[1]).read_text())
root = Path(spec["evidence_dir"])
root.mkdir(parents=True, exist_ok=False)
prompt = Path(spec["prompt"]).read_bytes()
assert hashlib.sha256(prompt).hexdigest() == spec["prompt_sha256"]
argv = [spec["codex"], "exec", "-C", spec["workdir"], "-m", spec["model"],
        "-s", "workspace-write", "--add-dir", spec["writable_root"],
        "--ignore-user-config", "--json", "-o", str(root / "final.txt"), "-"]
start = time.monotonic()
try:
    process = subprocess.run(argv, input=prompt, capture_output=True, timeout=300)
    code, stdout, stderr = process.returncode, process.stdout, process.stderr
except subprocess.TimeoutExpired as error:
    code, stdout, stderr = None, error.stdout or b"", error.stderr or b""
(root / "events.jsonl").write_bytes(stdout)
(root / "stderr.txt").write_bytes(stderr)
status = subprocess.run(["git", "status", "--porcelain=v1"], cwd=spec["workdir"],
                        capture_output=True, text=True).stdout.strip()
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=spec["workdir"],
                      capture_output=True, text=True).stdout.strip()
receipt = {"argv": argv, "exit_code": code, "elapsed_ms": round((time.monotonic()-start)*1000),
           "source_status": status, "source_head": head,
           "prompt_sha256": spec["prompt_sha256"]}
(root / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"run_id": spec["run_id"], "exit_code": code,
                  "elapsed_ms": receipt["elapsed_ms"], "source_status": status}))
