#170 fresh-consumer capture

Six independent `codex exec --json` sessions: three case names, baseline and
treatment each. Never resume or fork. Pin the same model, sandbox and executable.
The supervisor preserves process.json, raw events.jsonl, stderr and final.txt
outside both source clones. The consumer stops before executing any replay argv.
The observer reads command-completion events and packet files directly. Missing
thread identity, command events or final text is INCONCLUSIVE.
