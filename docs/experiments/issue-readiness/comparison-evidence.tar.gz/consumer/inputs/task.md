Prepare the first runnable packet for the assigned #170 case from the externally
selected portable handoff and host-local binding. Stop before executing replay,
launching another model, changing source or contacting GitHub. Report READY with
the packet path and run ID only when the command/result actually supports it;
otherwise report the exact missing owner input as BLOCKED.
