# Local Soodles work

Use the current repository instructions and the supplied `workspace.json` facts
to advance this work through one existing local owner transition. Preserve all
selected identities and capabilities exactly. Do not invent, replace, repair or
rediscover a missing input, and do not use a model or live provider transport.

Run the existing owner entry supported by the current facts. Write its complete
stdout JSON bytes unchanged to `work-output/raw-cli-receipt.json`. Write the
following object to `work-output/handoff.json`: `receipt.path` is the absolute
raw-receipt path recorded in `workspace.json`, and `next` is the receipt's
`next` JSON value unchanged, including a JSON `null` when that is the value.
The exact shape is `{"receipt":{"path":"..."},"next":...}`. Do not add
commentary or other fields to either file.
