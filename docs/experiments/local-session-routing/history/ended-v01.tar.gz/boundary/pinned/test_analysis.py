"""Synthetic aggregate controls only; these fixtures are not experiment runs."""

from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest

import analysis


SCOPE = "synthetic_control_not_run_evidence"


def pin(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


class AggregateControls(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        pins = {}
        for name in ("protocol", "oracle", "harness"):
            path = self.root / name
            path.write_text(SCOPE + ":" + name)
            pins[name] = pin(path)
        self.manifest = {"schema": 1, "pins": pins, "runs": []}
        values = {
            "selection": {"baseline": [10, 10, 11], "candidate": [8, 8, 9]},
            "confirmation": {"baseline": [5, 5, 6], "candidate": [4, 4, 5]},
        }
        serial = 0
        for split in ("selection", "confirmation"):
            for stratum, count in (("A", 3), ("B", 1), ("C", 1)):
                for arm in ("baseline", "candidate"):
                    commands = values[split][arm] if stratum == "A" else [20]
                    for repeat in range(count):
                        serial += 1
                        result = self.write_result(
                            str(serial), commands[repeat], classification="PASS")
                        self.manifest["runs"].append({
                            "split": split, "group": split + "-" + stratum,
                            "arm": arm, "stratum": stratum, "result": result,
                        })

    def tearDown(self):
        self.temporary.cleanup()

    def write_result(self, name, commands, classification):
        path = self.root / (name + ".json")
        value = {
            "evidence_validity": "VALID",
            "behavior": {"classification": classification},
            "cost": {"completed_commands": commands},
            "cost_comparison_eligible": classification == "PASS",
            "authorizes_landing": False,
        }
        path.write_text(json.dumps(value, sort_keys=True))
        return pin(path)

    def test_pins_and_legal_medians_adopt(self):
        result = analysis.aggregate(self.manifest)
        self.assertEqual(result["evidence_validity"], "VALID")
        self.assertEqual(result["behavior"], {"classification": "PASS"})
        self.assertTrue(result["adopt"])
        self.assertEqual(result["cost"]["selection"]["candidate_median"], 8)
        self.assertEqual(result["cost"]["confirmation"]["candidate_median"], 4)
        self.assertFalse(result["confirmation_pending"])
        self.assertFalse(result["authorizes_landing"])

    def test_selection_can_keep_without_confirmation_but_cannot_adopt(self):
        self.manifest["runs"] = [run for run in self.manifest["runs"]
                                 if run["split"] == "selection"]
        manifest = self.root / "selection-manifest.json"
        manifest.write_text(json.dumps(self.manifest, sort_keys=True))
        stdout = io.StringIO()
        with redirect_stdout(stdout):
            exit_code = analysis.main(["analysis.py", "--selection", str(manifest),
                                       pin(manifest)["sha256"]])
        result = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(result["behavior"], {"classification": "PASS"})
        self.assertTrue(result["keep_candidate"])
        self.assertTrue(result["confirmation_pending"])
        self.assertFalse(result["adopt"])
        self.assertEqual(set(result["cost"]), {"selection"})

    def test_changed_pin_is_invalid(self):
        Path(self.manifest["pins"]["harness"]["path"]).write_text("changed")
        with self.assertRaisesRegex(analysis.EvidenceError, "harness:digest_mismatch"):
            analysis.aggregate(self.manifest)

    def test_cross_split_group_collision_is_invalid(self):
        for run in self.manifest["runs"]:
            if run["split"] == "confirmation" and run["stratum"] == "A":
                run["group"] = "selection-A"
        with self.assertRaisesRegex(analysis.EvidenceError, "cross_split_group_collision"):
            analysis.aggregate(self.manifest)

    def test_failed_candidate_cannot_win_with_zero_cost(self):
        run = next(item for item in self.manifest["runs"]
                   if (item["split"], item["arm"], item["stratum"])
                   == ("selection", "candidate", "B"))
        run["result"] = self.write_result("failed-low-cost", 0, classification="FAIL")
        result = analysis.aggregate(self.manifest)
        self.assertEqual(result["evidence_validity"], "VALID")
        self.assertEqual(result["behavior"]["classification"], "FAIL")
        self.assertIsNone(result["cost"])
        self.assertFalse(result["adopt"])
        self.assertFalse(result["authorizes_landing"])


if __name__ == "__main__":
    unittest.main()
