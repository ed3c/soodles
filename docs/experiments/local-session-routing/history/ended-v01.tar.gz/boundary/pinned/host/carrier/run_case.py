#!/usr/bin/env python3
"""Run ONE supervisor-pinned case through a disposable, actual Noodle owner."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True

from capture_adapter import pinned, save, sha


def process_absent(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    return False


def required_pins(spec):
    source = Path(spec["source"]).resolve()
    result = {str(Path(__file__).resolve()), str(Path(__file__).with_name("capture_adapter.py").resolve()),
              spec["codex"], spec["code_mode_host"], spec["noodle"], spec["python"], spec["profile_template"], spec["task_file"]}
    result.update(str(p.resolve()) for p in source.glob("*.py"))
    result.update(str(p.resolve()) for p in (source / "policy").glob("*.json"))
    if spec.get("workspace_factory"):
        result.add(spec["workspace_factory"])
    return result


def prepare(draft, destination):
    """Read-only preflight plus one new external spec; no Noodle/model launch."""
    spec = json.loads(Path(draft).read_text())
    if Path(destination).exists():
        raise RuntimeError("prepared spec already exists")
    spec["pins"] = {path: sha(path) for path in sorted(required_pins(spec))}
    spec["source_head"] = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=spec["source"], text=True).strip()
    public = Path(spec["public_dir"]).resolve()
    spec["public_files"] = {str(p.relative_to(public)): sha(p) for p in public.rglob("*") if p.is_file()}
    save(destination, spec)
    print(json.dumps({"prepared": str(Path(destination).resolve()), "sha256": sha(destination),
                      "starts_model": False}))


def main():
    if len(sys.argv) == 4 and sys.argv[1] == "--prepare":
        return prepare(sys.argv[2], sys.argv[3])
    if len(sys.argv) != 3:
        raise SystemExit("usage: run_case.py /absolute/case.json CASE_SHA256")
    spec_path = Path(sys.argv[1]).resolve()
    pinned(spec_path, sys.argv[2])
    spec = json.loads(spec_path.read_text())
    if Path(sys.executable).resolve() != Path(spec["python"]).resolve():
        raise RuntimeError("run with the selected pinned Python interpreter")
    python_on_path = shutil.which("python3", path=spec["path"])
    if not python_on_path or Path(python_on_path).resolve() != Path(spec["python"]).resolve():
        raise RuntimeError("PATH must resolve python3 to the selected interpreter")
    source = Path(spec["source"]).resolve()
    adapter = Path(__file__).with_name("capture_adapter.py").resolve()
    required = required_pins(spec)
    if required - spec["pins"].keys():
        raise RuntimeError("missing pins: " + repr(sorted(required - spec["pins"].keys())))
    for path, expected in spec["pins"].items():
        pinned(path, expected)
    if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip() != spec["source_head"]:
        raise RuntimeError("source head changed")
    if not spec["probe_denied_paths"]:
        raise RuntimeError("private/other-run read probes required")
    public = Path(spec["public_dir"]).resolve()
    for reserved in (".git", ".gitignore", ".noodle", ".worktrees", ".noodle.toml"):
        if (public / reserved).exists():
            raise RuntimeError("public inputs use reserved fixture path: " + reserved)
    observed = {str(p.relative_to(public)): sha(p) for p in public.rglob("*") if p.is_file()}
    if observed != spec["public_files"] or any(p.is_symlink() for p in public.rglob("*")):
        raise RuntimeError("public input membership/bytes changed, or contains symlink")
    run = Path(spec["run_root"])
    if not run.is_absolute():
        raise RuntimeError("absolute fresh run_root required")
    run.mkdir()  # Refuse reuse before any runtime mutation.
    root = run / "control"
    shutil.copytree(public, root)
    for name in ("raw", "output", "home", "tmp", "provider"):
        (run / name).mkdir()
    commands = []
    env = {"PATH": spec["path"], "HOME": str(run / "home"),
           "TMPDIR": str(run / "tmp"), "TMPPREFIX": str(run / "tmp/zsh"), "PYTHONDONTWRITEBYTECODE": "1", "NOODLE_NO_BROWSER": "1"}

    def command(argv, timeout=30):
        result = subprocess.run([str(x) for x in argv], cwd=root, env=env,
                                capture_output=True, text=True, timeout=timeout)
        commands.append({"argv": [str(x) for x in argv], "exit": result.returncode,
                         "stdout": result.stdout, "stderr": result.stderr})
        save(run / "raw/supervisor-commands.json", commands)
        if result.returncode:
            raise RuntimeError("fixture command refused: " + repr(argv) + ": " + result.stderr)
        return result.stdout.strip()

    command(["git", "init", "-b", "main"])
    (root / ".gitignore").write_text(".noodle/\n.worktrees/\n")
    for skill in ("schedule", "execute"):
        folder = root / ".agents/skills" / skill
        folder.mkdir(parents=True, exist_ok=True)
        if (folder / "SKILL.md").exists():
            raise RuntimeError("public inputs collide with fixture skills")
        (folder / "SKILL.md").write_text(
            f"---\nname: {skill}\ndescription: one disposable carrier experiment\nschedule: fixture\n---\n"
            "Consume only the supplied bounded task. This is local fixture evidence, not provider delivery.\n")
    command(["git", "add", "."])
    command(["git", "-c", "user.name=Carrier Experiment", "-c", "user.email=fixture@example.invalid",
             "commit", "-m", "Pin public inputs for one disposable consumer"])
    if spec.get("workspace_factory"):
        facts = json.loads((root / "input.json").read_text())
        command([spec["python"], "-B", spec["workspace_factory"], root / "subject",
                 facts["work_id"], run / "output/workspace", root / "context.json"], timeout=90)
        workspace_root = run / "output/workspace"
        save(run / "raw/workspace-before.json", {
            "workspace": {"path": str(workspace_root / "workspace.json"),
                          "sha256": sha(workspace_root / "workspace.json")},
            "source_before": {str(p): sha(p) for p in workspace_root.rglob("*")
                              if p.is_file() and ".git" not in p.parts},
            "inventory": sorted(str(p.relative_to(workspace_root)) for p in workspace_root.rglob("*")
                                if p.is_file() and ".git" not in p.parts),
        })
    command(["git", "remote", "add", "origin", "https://github.com/ed3c/soodles.git"])
    (run / "provider/codex").symlink_to(adapter)
    sys.path.insert(0, str(source))
    import handoff_oracle
    import issue_execution
    envelope, envelope_path, _, issue = handoff_oracle._envelope(
        root, run, spec["noodle"], adapter, spec["fixture_issue"])
    argv = ["exec", "--skip-git-repo-check", "--json", "--model", spec["model"]]
    envelope["execution"]["carrier"]["codex"].update(argv=argv, model=spec["model"])
    assigned_task = Path(spec["task_file"]).read_text()
    carrier_task = ("\n\nThis is one bounded local fixture task. No GitHub or provider writes. "
             "The selected Python interpreter is " + spec["python"] + ". Use this absolute path for Python "
             "and subprocess argv; login shells may reset PATH. The public case input is input.json "
             "in the current worktree; do not search for tools or inputs. "
             "Use only this assigned case; put your report in " + str(run / "output") + ". "
             "At the end you yourself must emit one Noodle stage_message typed outcome using "
             + spec["noodle"] + " event emit --help and your actual NOODLE_SESSION_ID, NOODLE_ORDER_ID, "
             "NOODLE_STAGE_INDEX, NOODLE_PROJECT_DIR environment. Payload JSON has message (your actual result), "
             "blocking (false for completed, true for blocked), outcome (completed or blocked), "
             "order_id (actual NOODLE_ORDER_ID) and stage_index (integer actual NOODLE_STAGE_INDEX). "
             "Invoke [NOODLE_BINARY, '--project-dir', NOODLE_PROJECT_DIR, 'event', 'emit', 'stage_message', "
             "'--session', NOODLE_SESSION_ID, '--payload', json.dumps(payload)] as an argv array. "
             "Use completed only when the task is complete; otherwise report blocked honestly. "
             "The parent will not emit an outcome for you. Perform fixture setup and task writes only "
             "inside the assigned output directory. Keep carrier operations separate from task commands. "
             "Never modify the carrier canonical state, other sessions, public worktree source, "
             "carrier admission, or private data.\n")
    envelope["execution"]["task"] = assigned_task + carrier_task
    save(run / "raw/task-boundary.json", {
        "assigned_task_sha256": sha(spec["task_file"]), "assigned_task_bytes": len(assigned_task.encode()),
        "carrier_task": carrier_task, "carrier_task_bytes": len(carrier_task.encode()),
        "usage_scope": "whole CLI turn including carrier instructions; no token subtraction",
        "probe_time_in_model_elapsed": False,
        "carrier_operations": ["typed outcome emit help", "typed outcome emit"],
        "task_counts_scope": "exclude these fixed carrier operations; retain all raw actions and whole-turn usage"})
    save(envelope_path, envelope)
    # Config is ignored by Git; all worktree creation remains with Noodle.
    with (root / ".gitignore").open("a") as stream:
        stream.write(".noodle.toml\n")
    command(["git", "add", ".gitignore"])
    command(["git", "-c", "user.name=Carrier Experiment", "-c", "user.email=fixture@example.invalid",
             "commit", "-m", "Keep local runtime configuration outside public source"])
    head = command(["git", "rev-parse", "HEAD"])
    command(["git", "update-ref", "refs/remotes/origin/main", head])
    envelope["base_head"] = envelope["execution"]["source_head"] = head
    save(envelope_path, envelope)
    (root / ".noodle.toml").write_text(
        'mode = "supervised"\n[routing.defaults]\nprovider = "codex"\nmodel = ' + json.dumps(spec["model"]) +
        '\n[skills]\npaths = [".agents/skills"]\n[agents.codex]\npath = ' + json.dumps(str(run / "provider")) +
        '\nrequire_typed_outcome = true\n[concurrency]\nmax_concurrency = 1\n[runtime]\ndefault = "process"\n[server]\nenabled = false\n')
    binding = {**spec, "control": str(root), "run_root": str(run), "raw": str(run / "raw"),
               "output": str(run / "output"), "home": str(run / "home"), "tmp": str(run / "tmp"),
               "envelope": str(envelope_path), "envelope_sha256": sha(envelope_path), "issue_readback": issue}
    binding_path = run / "binding.json"
    save(binding_path, binding)
    env.update(EXPERIMENT_BINDING=str(binding_path), EXPERIMENT_BINDING_SHA256=sha(binding_path))
    command([spec["noodle"], "--project-dir", root, "start", "--once"])

    def reader(repository, number):
        if repository != "ed3c/soodles" or number != spec["fixture_issue"]:
            raise RuntimeError("unexpected fixture readback")
        return issue

    admitted = issue_execution.automatic(envelope_path, sha(envelope_path), root, reader=reader)
    save(run / "raw/admission.json", admitted)
    if admitted.get("published") is not True:
        raise RuntimeError("fixture did not publish exactly one new admission")
    logfile = (run / "raw/noodle.stdout").open("xb")
    errfile = (run / "raw/noodle.stderr").open("xb")
    process = subprocess.Popen([spec["noodle"], "--project-dir", str(root), "start"], cwd=root,
                               env=env, stdin=subprocess.DEVNULL, stdout=logfile, stderr=errfile,
                               start_new_session=True)
    observed_session = None
    try:
        deadline = time.monotonic() + spec["timeout_seconds"]
        while time.monotonic() < deadline:
            matches = []
            for path in (root / ".noodle/sessions").glob("*/spawn.json"):
                spawn = json.loads(path.read_text())
                if spawn.get("skill") == "execute":
                    matches.append(path.parent)
            if len(matches) > 1:
                raise RuntimeError("unexpected additional execute session; no retry authorized")
            if matches:
                observed_session = matches[0]
                receipt_path = run / "raw/exit.json"
                refusal_path = run / "raw/preflight-failure.json"
                process_path = observed_session / "process.json"
                metadata = json.loads(process_path.read_text()) if process_path.exists() else {}
                wrapper_pid = metadata.get("pid")
                wrapper_absent = (isinstance(wrapper_pid, int) and wrapper_pid > 0 and
                                  process_absent(wrapper_pid) and process_absent(-wrapper_pid))
                if receipt_path.exists():
                    receipt = json.loads(receipt_path.read_text())
                    if receipt.get("session_id") != observed_session.name:
                        raise RuntimeError("capture receipt session mismatch")
                    child_pid = receipt.get("pid")
                    if (wrapper_absent and isinstance(child_pid, int) and child_pid > 0 and
                            process_absent(child_pid)):
                        break
                elif refusal_path.exists():
                    refusal = json.loads(refusal_path.read_text())
                    if refusal.get("session_id") != observed_session.name or refusal.get("model_launched") is not False:
                        raise RuntimeError("invalid preflight failure receipt")
                    if wrapper_absent:
                        raise RuntimeError("consumer preflight refused: " + refusal["error"])
                elif wrapper_absent:
                    raise RuntimeError("consumer exited without capture receipt; raw evidence incomplete")
            if process.poll() is not None:
                raise RuntimeError("Noodle exited before terminal consumer readback")
            time.sleep(0.1)
        else:
            raise RuntimeError("bounded consumer observation timed out; no retry")
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGINT)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
            raise RuntimeError("Noodle failed graceful stop; retain fixture for owner recovery")
        finally:
            logfile.close()
            errfile.close()
    if observed_session is None:
        raise RuntimeError("no real execute session observed")
    events = [json.loads(line) for line in (observed_session / "events.ndjson").read_text().splitlines()]
    outcomes = [item for item in events if item.get("type") == "stage_message"]
    if len(outcomes) != 1:
        raise RuntimeError("expected exactly one consumer-emitted typed outcome")
    payload = outcomes[0].get("payload", {})
    if (outcomes[0].get("session_id") != observed_session.name or
            payload.get("order_id") != envelope["execution"]["order_id"] or
            payload.get("stage_index") != 0 or payload.get("outcome") not in ("completed", "blocked")):
        raise RuntimeError("typed outcome identity/status mismatch")
    capture = json.loads((run / "raw/exit.json").read_text())
    if not capture["drained"] or capture["session_id"] != observed_session.name:
        raise RuntimeError("raw capture incomplete or wrong session")
    metadata = json.loads((observed_session / "process.json").read_text())
    for target in (metadata["pid"], -metadata["pid"]):
        try:
            os.kill(target, 0)
        except ProcessLookupError:
            continue
        raise RuntimeError("consumer process/group still present; retain fixture")
    save(run / "raw/result.json", {"authorizes_landing": False, "provider_fixture": True,
                                  "session_dir": str(observed_session), "typed_outcome": outcomes[0],
                                  "noodle_exit": process.returncode, "process_and_group_absent": True,
                                  "scope": "one real Noodle session, CLI bytes, same-profile file probe"})
    # Keep all raw/session evidence. Cleanup only this Noodle-created checkout.
    command([spec["noodle"], "--project-dir", root, "worktree", "cleanup", envelope["execution"]["worktree"]])
    print(json.dumps({"run_root": str(run), "result": str(run / "raw/result.json")}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("single-case experiment refused: " + str(error), file=sys.stderr)
        raise SystemExit(64)
