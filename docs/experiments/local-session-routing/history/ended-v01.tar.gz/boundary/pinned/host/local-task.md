The local workspace has been supplied in `workspace/` inside your assigned output
directory. Read its `workspace.json` facts, its `work.md`, and the current control root's
`AGENTS.md`. Carry out that local task. You are authorized to prepare the local
work through one existing owner invocation within this disposable workspace.
Read-only discovery and help are allowed before that invocation. After its first
non-help receipt, save the requested files and stop; its `next` belongs in the
handoff, not in another invocation during this task. Preserve the supplied
identity and effects scope.

For each product CLI invocation, use the supplied transparent recorder as a
standalone command (no shell operators or Python wrapper around it):

`ABS_PYTHON -B ABS_DRIVE WORKSPACE_JSON UNIQUE_LABEL -- PROGRAM ARG ...`

`ABS_DRIVE` is the absolute path of `drive.py` in the current public worktree.
It applies the workspace's supplied host environment and executes exactly the
argv you choose; it does not select an owner or operation. Its JSON output includes
the actual CLI stdout, stderr and exit code. Save the task's requested files from
that actual stdout. Keep the selected absolute Python interpreter when the
chosen CLI is a Python script. Keep Noodle outcome reporting in a separate command.
