#!/usr/bin/env python3
"""One experiment's Noodle provider; no queue, retries, or parent-made outcome."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def pinned(path, expected):
    if sha(path) != expected:
        raise RuntimeError("changed pinned file: " + str(path))


def probe(profile, binding, env):
    """Read no private content in the parent; require EACCES/EPERM in child."""
    output = Path(binding["output"])
    denied = binding["probe_denied_paths"]
    links = []
    paths = []
    for index, name in enumerate(denied):
        target = Path(name)
        if not target.is_file():
            raise RuntimeError("probe target must already be a real file: " + name)
        link = output / (".denial-probe-" + str(index))
        link.symlink_to(target)
        links.append(link)
        paths.extend([str(target), str(target.parent / ".." / target.parent.name / target.name), str(link)])
        data_alias = Path("/System/Volumes/Data") / target.relative_to("/")
        if data_alias.is_file():
            paths.append(str(data_alias))
    program = '''import json,sys
from pathlib import Path
public, denied=json.loads(sys.argv[1])
result={"public_read":False,"denied":[]}
try:
 Path(public).read_bytes(); result["public_read"]=True
except OSError as e: result["public_error"]=type(e).__name__
for name in denied:
 try:
  Path(name).read_bytes(); result["denied"].append({"path":name,"result":"READABLE"})
 except OSError as e: result["denied"].append({"path":name,"result":type(e).__name__})
print(json.dumps(result))
sys.exit(0 if result["public_read"] and all(x["result"]=="PermissionError" for x in result["denied"]) else 1)
'''
    argv = ["/usr/bin/sandbox-exec", "-f", str(profile), binding["python"], "-B", "-c", program,
            json.dumps([binding["probe_public_path"], paths])]
    try:
        result = subprocess.run(argv, env=env, capture_output=True, timeout=20)
        save(Path(binding["raw"]) / "isolation-probe.json", {
            "argv": argv, "exit": result.returncode,
            "stdout": result.stdout.decode(errors="replace"),
            "stderr": result.stderr.decode(errors="replace"),
            "scope": "same-profile subprocess file reads, not full tool/IPC isolation"})
        if result.returncode:
            raise RuntimeError("same-profile read-denial probe failed; model was not launched")
    finally:
        for link in links:
            link.unlink()


def capture(binding):
    raw = Path(binding["raw"])
    session = os.environ["NOODLE_SESSION_ID"]
    worktree = Path.cwd().resolve()
    session_dir = Path(binding["control"]) / ".noodle/sessions" / session
    profile = raw / "consumer.sb"
    template = Path(binding["profile_template"]).read_text()
    replacements = {
        "WORKTREE": str(worktree), "CONTROL": binding["control"],
        "SESSION_DIR": str(session_dir), "EVENTS": str(session_dir / "events.ndjson"),
        "OUTPUT": binding["output"], "RUN_ROOT": binding["run_root"],
        "CODEX_HOME": binding["codex_home"], "HOME": binding["home"],
        "TMP": binding["tmp"], "NOODLE": binding["noodle"], "CODEX": binding["codex"],
        "PYTHON": binding["python"], "CONFIG": str(Path(binding["control"]) / ".noodle.toml"),
        "PYTHON_PREFIX": str(Path(sys.base_prefix).resolve()),
        "GIT_DIR": str(Path(binding["control"]) / ".git"),
        "CODE_MODE_HOST": binding["code_mode_host"],
        "PROVIDER_DIR": str(Path(binding["run_root"]) / "provider"),
    }
    for key, value in replacements.items():
        # Placeholder includes quotes, so paths remain valid SBPL strings.
        template = template.replace('"@' + key + '@"', json.dumps(value))
    if '"@' in template:
        raise RuntimeError("unresolved sandbox placeholder")
    # Startup needs ancestor metadata, not file contents from those directories.
    ancestors = sorted({str(parent) for value in replacements.values()
                        for parent in Path(value).parents})
    template += "\n(allow file-read-metadata\n" + "\n".join(
        " (literal " + json.dumps(parent) + ")" for parent in ancestors) + ")\n"
    profile.write_text(template)
    env = {"PATH": binding["path"], "HOME": binding["home"],
           "CODEX_HOME": binding["codex_home"], "TMPDIR": binding["tmp"],
           "TMPPREFIX": str(Path(binding["tmp"]) / "zsh"),
           "PYTHONDONTWRITEBYTECODE": "1", "NOODLE_NO_BROWSER": "1"}
    for key in ("NOODLE_PROJECT_DIR", "NOODLE_WORKTREE", "NOODLE_ORDER_ID",
                "NOODLE_STAGE_INDEX", "NOODLE_SESSION_ID", "NOODLE_PROVIDER", "NOODLE_MODEL"):
        if key in os.environ:
            env[key] = os.environ[key]
    probe(profile, binding, env)
    # Verify the actual Noodle-created worktree without launching a model.
    preflight = []
    git_argv = ["/usr/bin/git", "-C", str(worktree), "rev-parse",
                "--show-toplevel", "--is-inside-work-tree", "HEAD"]
    result = subprocess.run(git_argv, env=env, capture_output=True, text=True, timeout=20)
    preflight.append({"argv": git_argv, "exit": result.returncode,
                      "stdout": result.stdout, "stderr": result.stderr})
    save(raw / "preflight.json", preflight)
    if result.returncode or result.stdout.splitlines()[:2] != [str(worktree), "true"]:
        raise RuntimeError("actual worktree Git preflight failed; model was not launched")
    doctor_argv = ["/usr/bin/sandbox-exec", "-f", str(profile), binding["codex"],
                   "--no-daemon", "-C", str(worktree), "doctor", "--json"]
    result = subprocess.run(doctor_argv, env=env, capture_output=True, text=True, timeout=60)
    (raw / "doctor.json").write_text(result.stdout)
    (raw / "doctor.stderr").write_text(result.stderr)
    preflight.append({"argv": doctor_argv, "exit": result.returncode,
                      "stdout_path": str(raw / "doctor.json"),
                      "stderr_path": str(raw / "doctor.stderr")})
    save(raw / "preflight.json", preflight)
    if result.returncode:
        raise RuntimeError("sandboxed doctor failed; model was not launched")
    checks = json.loads(result.stdout)["checks"]
    detected = checks["git.environment"]["details"]
    configured = checks["config.load"]["details"]
    if (detected.get("repo detected") != "true" or
            detected.get("repo root") != str(worktree) or configured.get("cwd") != str(worktree)):
        raise RuntimeError("sandboxed doctor did not identify exact worktree; model was not launched")
    argv = ["/usr/bin/sandbox-exec", "-f", str(profile), binding["codex"],
            "--no-daemon", "exec", "--skip-git-repo-check", "--json",
            "--model", binding["model"], "--ignore-user-config", "--ephemeral",
            "--sandbox", "danger-full-access", "-c", 'approval_policy="never"']
    started = time.monotonic()
    save(raw / "launch.json", {"argv": argv, "cwd": str(worktree), "session_id": session,
                              "profile_sha256": sha(profile), "started_unix_ns": time.time_ns(),
                              "binding_sha256": os.environ["EXPERIMENT_BINDING_SHA256"]})
    # Child stays in Noodle's process group. No archive descriptors cross exec.
    child = subprocess.Popen(argv, env=env, stdin=sys.stdin.buffer,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
    return finish_capture(child, raw, session, started, sys.stdout.buffer, sys.stderr.buffer)


# Pinned Noodle parse/codex.go:87 and parse/codex_events.go:43 map these to
# EventResult/EventComplete. monitor/derive.go and loop/session_meta_repair.go
# can mark terminal and kill the wrapper before the actual process has exited.
def terminal_record(line):
    try:
        event = json.loads(line)
    except (ValueError, UnicodeError):
        return False
    if not isinstance(event, dict):
        return False
    payload = event.get("payload")
    return (event.get("type") == "turn.completed" or
            (event.get("type") == "event_msg" and isinstance(payload, dict) and
             payload.get("type") in ("task_complete", "complete", "session.complete")))


def finish_capture(child, raw, session, started, stdout, stderr, line_limit=1024 * 1024):
    """Archive eagerly; expose terminal only after real exit, EOF and receipt.

    Forward complete nonterminal lines immediately. From the first terminal
    onward, spool the exact suffix in stdout.bin to preserve byte order without
    an unbounded buffer. A line above the bound fails capture and terminates the
    producer, but the remaining bytes are still archived until EOF.
    """
    errors, eof = [], {}
    deferred = [None]

    def fail(message):
        errors.append(message)
        if child.poll() is None:
            child.terminate()

    def drain(stream, name, forward, gate=False):
        pending = bytearray()
        offset = 0
        forwarding = True
        try:
            with (raw / name).open("xb") as sink:
                while True:
                    data = os.read(stream.fileno(), 65536)
                    if not data:
                        eof[name] = True
                        break
                    sink.write(data)
                    sink.flush()
                    if not forwarding:
                        continue
                    if not gate:
                        try:
                            forward.write(data)
                            forward.flush()
                        except (BrokenPipeError, OSError) as error:
                            fail(name + ": forwarding failed: " + repr(error))
                            forwarding = False
                        continue
                    if deferred[0] is not None:
                        continue
                    pending.extend(data)
                    while pending:
                        newline = pending.find(b"\n")
                        length = len(pending) if newline < 0 else newline + 1
                        if length > line_limit:
                            fail(name + ": NDJSON line exceeds " + str(line_limit) + " bytes")
                            forwarding = False
                            pending.clear()
                            break
                        if newline < 0:
                            break
                        line = bytes(pending[:length])
                        del pending[:length]
                        if terminal_record(line):
                            deferred[0] = offset
                            pending.clear()
                            break
                        try:
                            forward.write(line)
                            forward.flush()
                        except (BrokenPipeError, OSError) as error:
                            fail(name + ": forwarding failed: " + repr(error))
                            forwarding = False
                            pending.clear()
                            break
                        offset += length
                if gate and pending and forwarding:
                    if terminal_record(pending):
                        deferred[0] = offset
                    else:
                        forward.write(pending)
                        forward.flush()
                sink.flush()
                os.fsync(sink.fileno())
        except BaseException as error:
            fail(name + ": " + repr(error))

    previous = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        previous[sig] = signal.signal(sig, lambda received, frame:
            child.send_signal(received) if child.poll() is None else None)
    threads = [threading.Thread(target=drain, args=(child.stdout, "stdout.bin", stdout, True)),
               threading.Thread(target=drain, args=(child.stderr, "stderr.bin", stderr))]
    try:
        for thread in threads:
            thread.start()
        code = child.wait()
        exited_ns = time.time_ns()
        for thread in threads:
            thread.join()
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    # Keep emitted usage verbatim. Bounded reads, including malformed/non-JSON.
    usage, parse_errors = [], []
    with (raw / "stdout.bin").open("rb") as stream:
        number = 0
        while line := stream.readline(line_limit + 1):
            number += 1
            if len(line) > line_limit:
                while line and not line.endswith(b"\n"):
                    line = stream.readline(line_limit + 1)
                parse_errors.append(number)
                continue
            try:
                event = json.loads(line)
            except (ValueError, UnicodeError):
                parse_errors.append(number)
                continue
            if isinstance(event, dict) and event.get("type") == "turn.completed" and "usage" in event:
                usage.append({"line": number, "usage": event["usage"]})
    drained = all(eof.get(name) for name in ("stdout.bin", "stderr.bin")) and not errors
    save(raw / "exit.json", {"exit": code, "pid": child.pid, "session_id": session,
                            "elapsed_seconds": time.monotonic() - started,
                            "process_exited_unix_ns": exited_ns, "streams_eof": eof,
                            "stdout_sha256": sha(raw / "stdout.bin"),
                            "stderr_sha256": sha(raw / "stderr.bin"),
                            "drained": drained, "capture_errors": errors,
                            "terminal_suffix_offset": deferred[0],
                            "forwarding_order": "actual process exit -> both stream EOF/fsync -> atomic exit.json -> original terminal suffix",
                            "non_json_lines": parse_errors, "emitted_usage": usage,
                            "complete_tool_process_capture": "unknown", "billing": "unknown"})
    # Noodle may kill this wrapper once terminal is visible. Child exit and raw
    # evidence are already durable; do not synthesize a successful terminal.
    if drained and deferred[0] is not None:
        with (raw / "stdout.bin").open("rb") as stream:
            stream.seek(deferred[0])
            while data := stream.read(65536):
                stdout.write(data)
                stdout.flush()
    return 74 if not drained else (code if code >= 0 else 128 - code)


def main():
    path = Path(os.environ["EXPERIMENT_BINDING"])
    pinned(path, os.environ["EXPERIMENT_BINDING_SHA256"])
    binding = json.loads(path.read_text())
    if Path(sys.executable).resolve() != Path(binding["python"]).resolve():
        raise RuntimeError("unselected Python interpreter")
    for filename, expected in binding["pins"].items():
        pinned(filename, expected)
    if os.environ.get("NOODLE_ORDER_ID") in (None, "", "schedule"):
        # Existing Noodle scheduler fixture: it admits nothing. Not a model run.
        sys.stdin.buffer.read()
        print(json.dumps({"type": "thread.started", "thread_id": "fixture-scheduler-no-model"}))
        print(json.dumps({"type": "turn.completed"}))
        return 0
    sys.path.insert(0, binding["source"])
    import issue_execution
    issue = binding["issue_readback"]

    def reader(repository, number):
        if repository != "ed3c/soodles" or number != issue["number"]:
            raise RuntimeError("unexpected fixture provider identity")
        return issue

    result = []

    def execute(binary, argv):
        if Path(binary).resolve() != Path(__file__).resolve():
            raise RuntimeError("unexpected selected carrier")
        try:
            result.append(capture(binding))
        except Exception as error:
            if not (Path(binding["raw"]) / "launch.json").exists():
                save(Path(binding["raw"]) / "preflight-failure.json", {
                    "session_id": os.environ["NOODLE_SESSION_ID"],
                    "model_launched": False, "error": str(error)})
            raise

    issue_execution.worker(binding["envelope"], binding["envelope_sha256"], Path.cwd(),
                           sys.argv[1:], reader=reader, execute=execute)
    if len(result) != 1:
        raise RuntimeError("worker guard did not execute one consumer")
    return result[0]


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print("experiment carrier refused: " + str(error), file=sys.stderr)
        raise SystemExit(64)
