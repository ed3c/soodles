#!/usr/bin/env python3
"""Bind the completed, independently captured artifacts of one selected case."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parents[1]


def pin(path):
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


packet = Path(sys.argv[1]).resolve()
stratum, oracle_path, oracle_sha = sys.argv[2:5]
oracle = Path(oracle_path).resolve()
assert pin(oracle)['sha256'] == oracle_sha, 'external oracle bytes changed'
case = json.loads((packet / 'case.json').read_text())
run = Path(case['run_root'])
before = json.loads((run / 'raw/workspace-before.json').read_text())
files = {'binding':'binding.json','launch':'raw/launch.json','exit':'raw/exit.json',
         'stdout':'raw/stdout.bin','stderr':'raw/stderr.bin','task_boundary':'raw/task-boundary.json',
         'isolation':'raw/isolation-probe.json','profile':'raw/consumer.sb'}
descriptor = {'stratum':stratum, 'capture':{name:pin(run/path) for name,path in files.items()},
              'workspace':before['workspace'], 'source_before':before['source_before'],
              'drive':pin(run/'control/drive.py')}
target = packet / 'descriptor.json'
if target.exists():
    raise FileExistsError(target)
target.write_text(json.dumps(descriptor,sort_keys=True,indent=2)+'\n')
argv = [sys.executable, '-B', str(oracle), str(target), pin(target)['sha256']]
result = subprocess.run(argv,capture_output=True,text=True)
(packet/'assessment.json').write_text(json.dumps({'argv':argv,'oracle_sha256':oracle_sha,
                                              'exit':result.returncode,'stderr':result.stderr},indent=2)+'\n')
(packet/'result.json').write_text(result.stdout)
print(result.stdout)
