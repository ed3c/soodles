#!/usr/bin/env python3
"""Create one disposable local Soodles workspace from committed source bytes."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


WORK_IDS = ("soodles-work-1", "soodles-work-2", "soodles-work-3")
CONTEXT_FIELDS = {
    "issue_number", "instruction_paths", "retain_prepared_receipt", "profile_home_fallback",
}
DEFAULT_CONTEXT = {
    "issue_number": None,
    "instruction_paths": [],
    "retain_prepared_receipt": False,
    "profile_home_fallback": False,
}

CONTROL_PATHS = (
    ".gitignore",
    "AGENTS.md",
    "soodles",
    "soodles.py",
    "issue-atom",
    "issue_atom.py",
    "supervisor-admission",
    "supervisor_admission.py",
    "candidate_publication.py",
    "issue_admission.py",
    "issue_execution.py",
    "github_reader.py",
    "repository_binding.py",
    "provider_credential.py",
    "landing.py",
    "dependency_binding.py",
    "provider_transport.py",
    "policy/runtime.lock.json",
    ".github/workflows/runtime.yml",
    ".agents/skills/issue-atom/SKILL.md",
    ".agents/skills/execute/SKILL.md",
    ".agents/skills/schedule/SKILL.md",
    ".agents/skills/verify-soodles/features/local-supervisor-admission.md",
)

OWNER_PATHS = (
    "landing.py",
    "provider-execute",
    "provider_transport.py",
    "soodles.py",
    "issue_admission.py",
    "repository_binding.py",
    "dependency_binding.py",
    "issue_execution.py",
    "policy/runtime.lock.json",
)

SENSITIVE_ENV = (
    "GH_TOKEN",
    "GITHUB_TOKEN",
    "GH_ENTERPRISE_TOKEN",
    "GITHUB_ENTERPRISE_TOKEN",
    "NOODLES_TOKEN_COMMAND",
    "NOODLES_APP_CLIENT_ID",
    "NOODLES_APP_INSTALLATION_ID",
    "NOODLES_APP_PRIVATE_KEY_PATH",
)

TASK_TEXT = """# Local Soodles work

Use the current repository instructions and the supplied `workspace.json` facts
to advance this work through one existing local owner transition. Preserve all
selected identities and capabilities exactly. Do not invent, replace, repair or
rediscover a missing input, and do not use a model or live provider transport.

Run the existing owner entry supported by the current facts. Write its complete
stdout JSON bytes unchanged to `work-output/raw-cli-receipt.json`. Write the
following object to `work-output/handoff.json`: `receipt.path` is the absolute
raw-receipt path recorded in `workspace.json`, and `next` is the receipt's
`next` JSON value unchanged, including a JSON `null` when that is the value.
The exact shape is `{"receipt":{"path":"..."},"next":...}`. Do not add
commentary or other fields to either file.
"""


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_context(path):
    if path is None:
        return dict(DEFAULT_CONTEXT)
    value = json.loads(Path(path).read_text())
    if not isinstance(value, dict) or set(value) != CONTEXT_FIELDS:
        raise ValueError("context must contain only the four workload fields")
    number = value["issue_number"]
    paths = value["instruction_paths"]
    if number is not None and (type(number) is not int or number < 1):
        raise ValueError("context.issue_number must be null or a positive integer")
    if (not isinstance(paths, list) or len(paths) != len(set(paths))
            or any(not isinstance(item, str) or not item or "\0" in item for item in paths)):
        raise ValueError("context.instruction_paths must be unique nonempty strings")
    if type(value["retain_prepared_receipt"]) is not bool:
        raise ValueError("context.retain_prepared_receipt must be boolean")
    if type(value["profile_home_fallback"]) is not bool:
        raise ValueError("context.profile_home_fallback must be boolean")
    return value


def command(argv, *, cwd=None, env=None):
    result = subprocess.run(
        list(map(str, argv)), cwd=cwd, env=env, stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode:
        raise RuntimeError(
            f"command failed ({result.returncode}): {list(map(str, argv))!r}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def git_env():
    env = dict(os.environ)
    for key in tuple(env):
        if key.startswith("GIT_"):
            env.pop(key)
    env.update({
        "GIT_AUTHOR_NAME": "Soodles Workspace",
        "GIT_AUTHOR_EMAIL": "workspace@example.invalid",
        "GIT_COMMITTER_NAME": "Soodles Workspace",
        "GIT_COMMITTER_EMAIL": "workspace@example.invalid",
        "GIT_AUTHOR_DATE": "2000-01-01T00:00:00+0000",
        "GIT_COMMITTER_DATE": "2000-01-01T00:00:00+0000",
    })
    return env


def git(root, *args):
    return command(["git", *args], cwd=root, env=git_env()).stdout.strip()


def source_identity(source):
    source = source.resolve()
    if not source.is_dir():
        raise ValueError(f"source must be a directory: {source}")
    root = Path(git(source, "rev-parse", "--show-toplevel")).resolve()
    prefix = git(source, "rev-parse", "--show-prefix")
    if prefix not in ("", "subject/"):
        raise ValueError(f"source must be the exact Git root or its subject/ directory: {source}")
    expected = root if not prefix else root / "subject"
    if source != expected.resolve():
        raise ValueError(f"source does not match its committed Git prefix: {source}")
    if git(root, "status", "--porcelain", "--untracked-files=all"):
        raise ValueError(f"source Git root must be clean: {root}")
    return root, prefix, git(root, "rev-parse", "HEAD")


def committed_blob(source_root, source_prefix, head, relative):
    repository_path = source_prefix + relative
    record = git(source_root, "ls-tree", head, "--", repository_path)
    fields = record.split(None, 3)
    if len(fields) != 4 or fields[1] != "blob" or fields[3] != repository_path:
        raise ValueError(f"missing committed regular file: {relative}")
    result = subprocess.run(
        ["git", "--no-pager", "show", f"{head}:{repository_path}"],
        cwd=source_root, env=git_env(), stdin=subprocess.DEVNULL,
        capture_output=True, timeout=30,
    )
    if result.returncode:
        raise RuntimeError(f"cannot read committed file: {relative}")
    return result.stdout, fields[0] == "100755"


def copy_committed(source_root, source_prefix, head, relative, destination_root):
    data, executable = committed_blob(source_root, source_prefix, head, relative)
    target = destination_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    target.chmod(0o755 if executable else 0o644)
    return target


def build_control(source_root, source_prefix, source_head, output):
    control = output / "control"
    command(["git", "init", "-b", "main", control], env=git_env())
    instruction_files = git(source_root, "ls-tree", "-r", "--name-only", source_head, "--",
                            source_prefix + ".agents/skills", source_prefix + "contracts").splitlines()
    paths = set(CONTROL_PATHS) | {name[len(source_prefix):] for name in instruction_files}
    for relative in sorted(paths):
        copy_committed(source_root, source_prefix, source_head, relative, control)
    item = control / "work-item.txt"
    item.write_text("bounded local Soodles work\n")
    git(control, "add", ".")
    git(control, "commit", "-m", "Create disposable Soodles workspace")
    git(control, "remote", "add", "origin", "https://github.com/ed3c/soodles.git")
    return control, git(control, "rev-parse", "HEAD"), sha256(item.read_bytes())


def executable(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    path.chmod(0o700)
    return {"path": str(path), "sha256": sha256(path.read_bytes())}


def build_carrier(output):
    root = output / "host" / "bin"
    noodle = executable(root / "noodle", "#!/bin/sh\nexit 78\n")
    codex = executable(root / "codex", "#!/bin/sh\nexit 78\n")
    return {
        "platform": platform.system().lower() + "_" + platform.machine().lower(),
        "noodle": noodle,
        "codex": {
            **codex,
            "model": "local-worker",
            "argv": [
                "exec", "--skip-git-repo-check", "--json", "--model", "local-worker",
            ],
        },
    }


def build_owner(source_root, source_prefix, source_head, output):
    owner = output / "external-owner"
    hashes = {}
    for relative in OWNER_PATHS:
        target = copy_committed(source_root, source_prefix, source_head, relative, owner)
        hashes[relative] = sha256(target.read_bytes())
    return {
        "path": str(owner / "soodles.py"),
        "sha256": hashes["soodles.py"],
        "verifier_sha256": sha256(json.dumps(
            hashes, sort_keys=True, separators=(",", ":"),
        ).encode()),
    }


def issue_body(base_head, item_sha256):
    contract = {
        "schema": 3,
        "trigger": "local work request",
        "source": "authorized local session",
        "owner": "local Soodles owner",
        "changes": ["advance the supplied work"],
        "write_paths": ["work-item.txt"],
        "behavior": ["preserve the selected local owner"],
        "defect_controls": ["refuse changed identity"],
        "non_cases": ["provider delivery"],
        "dependencies": [],
        "acceptance": "bounded local owner receipt",
        "delivery": "outside this workspace",
        "reconciliation": "outside this workspace",
        "feature_scope": "one local owner transition",
        "required_paths": ["work-item.txt"],
        "evidence_manifest": "work-item.txt",
        "base_head": base_head,
        "frozen_paths": [{
            "path": "work-item.txt", "revision": "head", "sha256": item_sha256,
        }],
    }
    return (
        "<!-- soodles:execution-v1 -->\n```json\n"
        + json.dumps(contract, sort_keys=True)
        + "\n```\n<!-- /soodles:execution-v1 -->"
    )


def write_selection(output, control, base_head, item_sha256, carrier, owner, context):
    issue = {
        "title": "Local Soodles work",
        "body": issue_body(base_head, item_sha256),
    }
    if context["issue_number"] is not None:
        issue["number"] = context["issue_number"]
    selection = {
        "schema": 1,
        "repository": "ed3c/soodles",
        "control_root": str(control),
        "issue": issue,
        "task": "Advance the supplied local Soodles work through its current owner.",
        "carrier": carrier,
        "landing_owner": owner,
        "instruction_paths": context["instruction_paths"],
    }
    inputs = output / "inputs"
    inputs.mkdir()
    path = inputs / "selection.json"
    path.write_bytes(canonical(selection))
    return path, sha256(path.read_bytes())


def cli_environment(output, home_fallback):
    home = output / "host" / "home"
    config = output / "host" / "config"
    home.mkdir(parents=True)
    environment = {
        "HOME": str(home),
        "PATH": os.environ["PATH"],
        "NOODLES_TOKEN_COMMAND": "",
        "GH_TOKEN": "",
        "GITHUB_TOKEN": "",
        "GH_ENTERPRISE_TOKEN": "",
        "GITHUB_ENTERPRISE_TOKEN": "",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    if home_fallback:
        (home / ".config" / "soodles").mkdir(parents=True)
    else:
        config.mkdir(parents=True)
        environment["XDG_CONFIG_HOME"] = str(config)
    return environment


def materialize(control, selection, selection_sha256, output, environment, *, target=None, retain=False):
    target = output / ".selected" if target is None else target
    env = dict(os.environ)
    for name in SENSITIVE_ENV:
        env.pop(name, None)
    env.update(environment)
    result = command([
        str(Path(sys.executable).resolve()), "-B", control / "supervisor-admission", "authorize",
        selection, selection_sha256, target,
    ], cwd=control, env=env)
    receipt = json.loads(result.stdout)
    authorization = target / "authorization.json"
    data = authorization.read_bytes()
    digest = sha256(data)
    if receipt.get("authorization") != {"path": str(authorization), "sha256": digest}:
        raise RuntimeError("supervisor-admission returned inconsistent authorization identity")
    if not retain:
        shutil.rmtree(target)
    return data, digest


def create(source, work_id, output, context_path=None):
    source_root, source_prefix, source_head = source_identity(source)
    context = load_context(context_path)
    if work_id not in WORK_IDS:
        raise ValueError(f"unknown work id: {work_id}")
    if context["retain_prepared_receipt"] and work_id != "soodles-work-2":
        raise ValueError("retained producer receipt applies only to soodles-work-2")
    if not output.is_absolute():
        raise ValueError("output must be absolute")
    output = output.parent.resolve() / output.name
    if output.is_relative_to(source_root):
        raise ValueError("output must be outside the source root")
    if output.exists():
        raise FileExistsError(output)
    if not output.parent.is_dir():
        raise FileNotFoundError(output.parent)

    output.mkdir(mode=0o700)
    try:
        control, base_head, item_sha = build_control(
            source_root, source_prefix, source_head, output,
        )
        carrier = build_carrier(output)
        owner = build_owner(source_root, source_prefix, source_head, output)
        selection, selection_sha = write_selection(
            output, control, base_head, item_sha, carrier, owner, context,
        )
        environment = cli_environment(output, context["profile_home_fallback"])
        facts = {
            "schema": 1,
            "work_id": work_id,
            "context": context,
            "source": {"head": source_head, "prefix": source_prefix},
            "control_root": str(control),
            "entries": {
                "supervisor_admission": str(control / "supervisor-admission"),
                "issue_atom": str(control / "issue-atom"),
            },
            "host": {
                "platform": carrier["platform"],
                "python": str(Path(sys.executable).resolve()),
                "environment": environment,
            },
        }

        task = output / "work.md"
        task.write_text(TASK_TEXT)
        work_output = output / "work-output"
        work_output.mkdir()
        facts["task"] = {
            "path": str(task),
            "output": str(work_output),
            "raw_cli_receipt": str(work_output / "raw-cli-receipt.json"),
            "handoff": str(work_output / "handoff.json"),
        }

        handoff = output / "handoff"
        handoff.mkdir()
        if work_id == "soodles-work-1":
            facts["selection"] = {
                "path": str(selection),
                "sha256": selection_sha,
                "external_output": str(handoff / "prepared"),
            }
        else:
            retained = context["retain_prepared_receipt"]
            selected_output = handoff / "prepared" if retained else None
            data, digest = materialize(
                control, selection, selection_sha, output, environment,
                target=selected_output, retain=retained,
            )
            selection.unlink()
            selection.parent.rmdir()
            authorization = selected_output / "authorization.json" if retained else handoff / "authorization.json"
            if retained:
                authorization.unlink()
            if work_id == "soodles-work-3":
                authorization.write_bytes(data)
                authorization.chmod(0o600)
            environment["SOODLES_AUTHORIZATION_SHA256"] = digest
            facts["authorization"] = {
                "path": str(authorization),
                "sha256": digest,
            }
            if retained:
                facts["authorization"]["prepared_receipt"] = str(selected_output / "prepared.json")

        workspace = output / "workspace.json"
        workspace.write_bytes(canonical(facts))
        print(json.dumps({"work_id": work_id, "workspace": str(workspace)}, sort_keys=True))
        return 0
    except BaseException:
        shutil.rmtree(output, ignore_errors=True)
        raise


def parser():
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("source", type=Path)
    value.add_argument("work_id", choices=WORK_IDS)
    value.add_argument("output", type=Path)
    value.add_argument("context", type=Path, nargs="?")
    return value


def main():
    args = parser().parse_args()
    return create(args.source, args.work_id, args.output, args.context)


if __name__ == "__main__":
    raise SystemExit(main())
